/**
 * @file ui_balance.c
 * @brief UI 平衡控制页实现
 * @note  屏幕只有 128x160, 每行最多 21 个字符, 所有显示串必须 ≤21 字符
 *        (超了 ui_draw_string 会自动换行, 把下面的布局冲掉)。
 * @author ESP32 平衡轮腿机器人
 */

#include "ui_balance.h"
#include "balance.h"
#include "servo.h"
#include "tft_display.h"
#include <stdio.h>
#include <string.h>

/* ========== 绘制坐标 (Y) ========== */
#define Y_TITLE      1       /* 标题栏 */
#define Y_STATE      14      /* 状态机状态 + 使能标志 */
#define Y_PITCH      24      /* 俯仰角 + 角速度 */
#define Y_ROLL       34      /* 横滚角 (已扣配平零点) */
#define Y_TARGET     44      /* 目标倾角 */
#define Y_BALOUT     54      /* 平衡环输出 */
#define Y_MOTOR      64      /* 电机实际输出 */
#define Y_SPEED      74      /* 轮速 + 配平补偿 */
#define Y_SERVO      84      /* 两路舵机逻辑角 */
#define Y_SEP        96      /* 分隔线 */
#define Y_HINT       102     /* 按键提示第 1 行 */
#define Y_HINT2      114     /* 按键提示第 2 行 */

/* 数值区 X 起点 + 擦除宽度 (擦除宽度必须 >= 文本最长宽度, 否则位数变化会留残影) */
#define VAL_X        30
#define VAL_W        96

/* 状态机状态显示名 */
static const char *STATE_NAMES[] = {
    "IDLE", "STANDBY", "BALANCING", "FALLEN"
};

/* 上一次显示的字符串缓存 (用来比对是否需要重画) */
static char s_prev_state[24] = "";
static char s_prev_pitch[24] = "";
static char s_prev_roll[24]  = "";
static char s_prev_target[24] = "";
static char s_prev_balout[24] = "";
static char s_prev_motor[24] = "";
static char s_prev_speed[24] = "";
static char s_prev_servo[24] = "";

/**
 * @brief 擦除并重画一行数值 (仅当内容变化时)
 */
static void draw_val_if_changed(uint8_t y, const char *str, uint16_t color, char *prev)
{
    if (strcmp(str, prev) == 0) return;  /* 内容未变, 跳过 */
    ui_fill_rect(VAL_X, y, VAL_W, UI_FONT_H, TFT_COLOR_BLACK);
    ui_draw_string(VAL_X, y, str, color, TFT_COLOR_BLACK);
    strncpy(prev, str, 23);
    prev[23] = '\0';
}

/**
 * @brief 绘制静态骨架 (标题 + 标签 + 分隔线 + 提示)
 */
static void ui_balance_draw_static(void)
{
    tft_clear(TFT_COLOR_BLACK);

    ui_fill_rect(0, 0, UI_SCREEN_W, UI_FONT_H + 2, TFT_COLOR_WHITE);
    ui_draw_string(2, Y_TITLE, "BALANCE CTRL", TFT_COLOR_BLACK, TFT_COLOR_WHITE);

    ui_draw_string(2, Y_STATE, "St:",  TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_PITCH, "Pit:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_ROLL,  "Rol:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_TARGET,"Tgt:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_BALOUT,"Bal:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_MOTOR, "Mot:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_SPEED, "Whl:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_SERVO, "Svo:", TFT_COLOR_CYAN, TFT_COLOR_BLACK);

    ui_draw_hline(0, Y_SEP, UI_SCREEN_W, TFT_COLOR_BLUE);

    ui_draw_string(2, Y_HINT,  "[K1]Bk [K2]On/Off",
                   TFT_COLOR_GREEN, TFT_COLOR_BLACK);
    ui_draw_string(2, Y_HINT2, "[K3]E-Stop (clr int)",
                   TFT_COLOR_RED, TFT_COLOR_BLACK);
}

/**
 * @brief 刷新所有实时数值 (只重画变化的行)
 */
static void ui_balance_refresh_vals(void)
{
    bal_data_t d = {0};
    balance_get_data(&d);

    char buf[24];
    bal_state_t st = balance_get_state();
    if ((int)st < 0 || (int)st > BAL_STATE_FALLEN) st = BAL_STATE_IDLE;

    /* 状态行: BALANCING 绿色, FALLEN 红色, STANDBY 黄色 */
    uint16_t scolor = TFT_COLOR_WHITE;
    if (st == BAL_STATE_BALANCING) scolor = TFT_COLOR_GREEN;
    if (st == BAL_STATE_FALLEN)    scolor = TFT_COLOR_RED;
    if (st == BAL_STATE_STANDBY)  scolor = TFT_COLOR_YELLOW;

    if (balance_is_enabled()) {
        snprintf(buf, sizeof(buf), "%s ON", STATE_NAMES[st]);
    } else {
        snprintf(buf, sizeof(buf), "%s OFF", STATE_NAMES[st]);
    }
    draw_val_if_changed(Y_STATE, buf, scolor, s_prev_state);

    /* 修正后姿态角 + 角速度 */
    snprintf(buf, sizeof(buf), "%6.2f g%6.1f", (double)d.pitch, (double)d.gyro);
    draw_val_if_changed(Y_PITCH, buf, TFT_COLOR_WHITE, s_prev_pitch);

    /* 横滚角: 已扣配平零点, 与横滚闭环用的是同一个值 */
    snprintf(buf, sizeof(buf), "%6.2f deg", (double)d.roll);
    draw_val_if_changed(Y_ROLL, buf, TFT_COLOR_MAGENTA, s_prev_roll);

    snprintf(buf, sizeof(buf), "%6.2f deg", (double)d.target_pitch);
    draw_val_if_changed(Y_TARGET, buf, TFT_COLOR_YELLOW, s_prev_target);

    snprintf(buf, sizeof(buf), "%6.1f %%", (double)d.bal_out);
    draw_val_if_changed(Y_BALOUT, buf, TFT_COLOR_MAGENTA, s_prev_balout);

    snprintf(buf, sizeof(buf), "A%+4d B%+4d", d.motor_a, d.motor_b);
    draw_val_if_changed(Y_MOTOR, buf, TFT_COLOR_YELLOW, s_prev_motor);

    /* 轮速 + 配平补偿 (一眼看出补偿有没有在动) */
    snprintf(buf, sizeof(buf), "%5.1f T%5.2f", (double)d.speed, (double)d.trim_comp);
    draw_val_if_changed(Y_SPEED, buf, TFT_COLOR_GREEN, s_prev_speed);

    /* 两路舵机逻辑角 (不含横滚偏置, 与 App/LCD 主页一致) */
    snprintf(buf, sizeof(buf), "%3u/%3u",
             (unsigned)servo_get_angle(SERVO_1),
             (unsigned)servo_get_angle(SERVO_2));
    draw_val_if_changed(Y_SERVO, buf, TFT_COLOR_GREEN, s_prev_servo);
}

/* ========== 页面回调 ========== */

static void page_enter(void)
{
    /* 清空缓存, 强制全刷 */
    s_prev_state[0] = '\0';
    s_prev_pitch[0] = '\0';
    s_prev_roll[0]  = '\0';
    s_prev_target[0] = '\0';
    s_prev_balout[0] = '\0';
    s_prev_motor[0] = '\0';
    s_prev_speed[0] = '\0';
    s_prev_servo[0] = '\0';

    /* 不在这里停机: App 起立后 LCD 会自动切进本页, 此时平衡已在运行 */
    ui_balance_draw_static();
    ui_balance_refresh_vals();
}

static void page_exit(void)
{
    balance_set_enable(false);   /* 退出页面时保证电机不转 */
}

static void page_key(ui_key_t key)
{
    if (key == UI_KEY_K1) {
        lcd_ui_switch_to(UI_PAGE_MENU);
    } else if (key == UI_KEY_K2) {
        /* 车没扶正时 balance_set_enable 会拒绝, 状态行会显示出来 */
        balance_set_enable(!balance_is_enabled());
        ui_balance_refresh_vals();
    } else if (key == UI_KEY_K3) {
        balance_emergency_stop();   /* 清空 PID 积分, 避免下次启动猛冲 */
        ui_balance_refresh_vals();
    }
}

static void page_refresh(void)
{
    ui_balance_refresh_vals();
}

/* ========== 页面注册 ========== */

static const ui_page_t balance_page = {
    .id         = UI_PAGE_BALANCE,
    .title      = "Balance",
    .on_enter   = page_enter,
    .on_exit    = page_exit,
    .on_key     = page_key,
    .on_refresh = page_refresh,
};

esp_err_t ui_balance_register(void)
{
    return lcd_ui_register_page(&balance_page);
}
