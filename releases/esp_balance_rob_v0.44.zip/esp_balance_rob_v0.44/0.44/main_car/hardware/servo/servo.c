/**
 * @file servo.c
 * @brief 舵机控制驱动实现 (标准 PWM 舵机, 50Hz, 1-2ms 脉宽)
 * @note  - 双路独立目标角度 (逻辑角度), 物理安装不对称由 servo_logic_to_phys() 补偿
 *        - 后台任务每 SERVO_KEEP_ALIVE_MS ms 重新同步硬件, 跨页不失力不跳变
 *        - Roll 补偿: 根据横滚角自动调整左右腿长度适应地形
 * @author ESP32 机械狗项目
 */

#include "servo.h"
#include "driver/ledc.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

static const char *TAG = "SERVO";

/* 舵机 GPIO 与 LEDC 通道映射表 */
static const struct {
    gpio_num_t      gpio;
    ledc_channel_t  channel;
} servo_map[SERVO_2 + 1] = {
    [SERVO_1] = { .gpio = SERVO_1_GPIO, .channel = SERVO_1_CHANNEL },
    [SERVO_2] = { .gpio = SERVO_2_GPIO, .channel = SERVO_2_CHANNEL },
};

/* 两路舵机独立的目标角度 (用户操作的"逻辑角度", UI 显示这个值) */
static uint8_t s_angle[SERVO_2 + 1] = {
    [SERVO_1] = SERVO_DEFAULT_ANGLE,
    [SERVO_2] = SERVO_DEFAULT_ANGLE,
};

/* 舵机更新统计 (用于诊断) */
static uint32_t s_update_count = 0;    // 总更新次数
static uint32_t s_update_errors = 0;   // 更新失败次数

/* 逻辑角度变化计数 (只在上层真的改了目标角度时 +1, 供状态灯判断) */
static volatile uint32_t s_change_seq = 0;

/* Roll 补偿状态 */
static float s_roll_angle = 0.0f;       // 当前 Roll 角 (°, 外部定期更新)
static bool s_balance_mode = false;     // 是否在平衡起立状态 (外部设置)

/* 横滚闭环的左右角度偏置 (°, 正 = 角度增大 = 收腿), 只影响硬件输出 */
static int8_t s_trim[SERVO_2 + 1] = { 0 };

void servo_set_roll_trim(int8_t left_delta, int8_t right_delta)
{
    s_trim[SERVO_1] = left_delta;
    s_trim[SERVO_2] = right_delta;
}

/**
 * @brief 将逻辑角度转换为舵机 ID 对应的物理角度
 * @note  SERVO_1 = GPIO14 (正向舵机) → 物理角 = 180-逻辑
 *        SERVO_2 = GPIO13 (反向舵机, 调 80° 实际转 100°) → 不映射
 * @param id 舵机 ID
 * @param logic_angle 逻辑角度 (0-180)
 * @return 物理角度 (0-180)
 */
static uint8_t servo_logic_to_phys(servo_id_t id, uint8_t logic_angle)
{
    if (id == SERVO_1) {
        /* SERVO_1 = GPIO14 (正向), 走反向得到 180-逻辑 */
        int phys = (int)SERVO_MAX_ANGLE - (int)logic_angle;
        if (phys < 0) phys = 0;
        if (phys > SERVO_MAX_ANGLE) phys = SERVO_MAX_ANGLE;
        return (uint8_t)phys;
    }
    /* SERVO_2 = GPIO13 (反向), 不映射, 反向舵机自己反向, 净结果 = 180-逻辑 */
    return logic_angle;
}

/**
 * @brief 将舵机 ID 的逻辑角度写到硬件 (经逻辑→物理映射)
 * @note  逻辑角度会先叠加横滚偏置 s_trim[], 再映射到物理角度;
 *        s_angle[] 保存的仍是用户目标, 不受偏置影响。
 */
static esp_err_t servo_write_hw(servo_id_t id, uint8_t logic_angle)
{
    int trimmed = (int)logic_angle + (int)s_trim[id];
    if (trimmed < SERVO_LIMIT_MIN) trimmed = SERVO_LIMIT_MIN;
    if (trimmed > SERVO_LIMIT_MAX) trimmed = SERVO_LIMIT_MAX;
    uint8_t  phys = servo_logic_to_phys(id, (uint8_t)trimmed);
    uint32_t duty = servo_angle_to_duty(phys);

    s_update_count++;

    esp_err_t ret = ledc_set_duty(SERVO_PWM_MODE, servo_map[id].channel, duty);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "舵机%d ledc_set_duty失败: %s", id, esp_err_to_name(ret));
        s_update_errors++;
        return ret;
    }

    ret = ledc_update_duty(SERVO_PWM_MODE, servo_map[id].channel);
    if (ret != ESP_OK) {
        /* 更新失败时重试一次 (ESP32 LEDC 有时需要多次调用) */
        ESP_LOGW(TAG, "舵机%d ledc_update_duty失败, 重试...", id);
        s_update_errors++;
        ret = ledc_update_duty(SERVO_PWM_MODE, servo_map[id].channel);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "舵机%d ledc_update_duty重试仍失败: %s", id, esp_err_to_name(ret));
            return ret;
        }
    }
    return ESP_OK;
}

/**
 * @brief 将脉宽(us)转换为 LEDC 占空比
 * @param pulse_us 脉宽(微秒)
 * @return LEDC 占空比值
 */
static uint32_t servo_pulse_to_duty(uint16_t pulse_us)
{
    /* 周期 = 1/50Hz = 20ms = 20000us, 14bit 分辨率 */
    uint32_t max_duty = (1 << 14) - 1;
    return (uint32_t)((uint64_t)pulse_us * max_duty / 20000);
}

/**
 * @brief 将角度转换为 LEDC 占空比
 */
uint32_t servo_angle_to_duty(uint8_t angle)
{
    if (angle > SERVO_MAX_ANGLE) angle = SERVO_MAX_ANGLE;
    uint16_t pulse = SERVO_MIN_PULSE_US +
                     (uint32_t)(angle * (SERVO_MAX_PULSE_US - SERVO_MIN_PULSE_US))
                     / SERVO_MAX_ANGLE;
    return servo_pulse_to_duty(pulse);
}

/**
 * @brief 初始化所有舵机
 */
esp_err_t servo_init(void)
{
    ledc_timer_config_t timer_cfg = {
        .duty_resolution = SERVO_PWM_RES,
        .freq_hz = SERVO_PWM_FREQ,
        .speed_mode = SERVO_PWM_MODE,
        .timer_num = SERVO_PWM_TIMER,
        .clk_cfg = LEDC_AUTO_CLK,
    };

    esp_err_t ret = ledc_timer_config(&timer_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "LEDC 定时器配置失败");
        return ret;
    }

    for (int i = 0; i <= SERVO_2; i++) {
        ledc_channel_config_t ch_cfg = {
            .channel    = servo_map[i].channel,
            .duty       = 0,
            .gpio_num   = servo_map[i].gpio,
            .speed_mode = SERVO_PWM_MODE,
            .timer_sel  = SERVO_PWM_TIMER,
        };

        ret = ledc_channel_config(&ch_cfg);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "舵机 %d 通道配置失败", i + 1);
            return ret;
        }
    }

    /* 两路归位到默认角度 (逻辑角度) */
    s_angle[SERVO_1] = SERVO_DEFAULT_ANGLE;
    s_angle[SERVO_2] = SERVO_DEFAULT_ANGLE;

    /* 舵机初始化后先不给力，等待 100ms 让舵机完全上电准备 */
    vTaskDelay(pdMS_TO_TICKS(100));
    servo_apply_both();

    ESP_LOGI(TAG, "舵机初始化成功 (S1(左)=GPIO%d/正向+180-x, S2(右)=GPIO%d/反向+直通, 50Hz, 默认=%d°, 限位=%d~%d)",
             SERVO_1_GPIO, SERVO_2_GPIO, SERVO_DEFAULT_ANGLE,
             SERVO_LIMIT_MIN, SERVO_LIMIT_MAX);
    return ESP_OK;
}

/**
 * @brief 设置单路舵机角度 (限位 + 立即同步到该路硬件)
 */
esp_err_t servo_set_angle(servo_id_t id, uint8_t angle)
{
    if (id > SERVO_2) {
        return ESP_ERR_INVALID_ARG;
    }
    if (angle < SERVO_LIMIT_MIN) angle = SERVO_LIMIT_MIN;
    if (angle > SERVO_LIMIT_MAX) angle = SERVO_LIMIT_MAX;
    if (s_angle[id] != angle) s_change_seq++;
    s_angle[id] = angle;
    return servo_write_hw(id, angle);
}

/**
 * @brief 同时设置两路舵机角度 (限位 + 立即同步)
 */
esp_err_t servo_set_both(uint8_t angle)
{
    if (angle < SERVO_LIMIT_MIN) angle = SERVO_LIMIT_MIN;
    if (angle > SERVO_LIMIT_MAX) angle = SERVO_LIMIT_MAX;
    if (s_angle[SERVO_1] != angle || s_angle[SERVO_2] != angle) s_change_seq++;
    s_angle[SERVO_1] = angle;
    s_angle[SERVO_2] = angle;
    esp_err_t ret = servo_write_hw(SERVO_1, angle);
    if (ret != ESP_OK) return ret;
    return servo_write_hw(SERVO_2, angle);
}

/**
 * @brief 获取单路舵机当前角度
 */
uint8_t servo_get_angle(servo_id_t id)
{
    if (id > SERVO_2) {
        return 0;
    }
    return s_angle[id];
}

uint32_t servo_get_change_seq(void)
{
    return s_change_seq;
}

/**
 * @brief 把两路舵机当前角度同步到硬件
 */
esp_err_t servo_apply_both(void)
{
    for (int i = 0; i <= SERVO_2; i++) {
        esp_err_t ret = servo_write_hw((servo_id_t)i, s_angle[i]);
        if (ret != ESP_OK) return ret;
    }
    return ESP_OK;
}

/**
 * @brief 获取舵机诊断信息 (用于调试)
 * @param[out] duty1 舵机1当前实际占空比
 * @param[out] duty2 舵机2当前实际占空比
 * @param[out] pulse1_us 舵机1当前脉宽(微秒)
 * @param[out] pulse2_us 舵机2当前脉宽(微秒)
 */
void servo_get_diagnostics(uint32_t *duty1, uint32_t *duty2,
                          uint32_t *pulse1_us, uint32_t *pulse2_us)
{
    if (duty1) *duty1 = ledc_get_duty(SERVO_PWM_MODE, servo_map[SERVO_1].channel);
    if (duty2) *duty2 = ledc_get_duty(SERVO_PWM_MODE, servo_map[SERVO_2].channel);

    /* 计算实际脉宽: pulse_us = duty * 20000 / 16383 */
    if (pulse1_us && duty1) *pulse1_us = (uint32_t)((uint64_t)(*duty1) * 20000 / 16383);
    if (pulse2_us && duty2) *pulse2_us = (uint32_t)((uint64_t)(*duty2) * 20000 / 16383);
}

/**
 * @brief 后台"保持运行"任务: 周期性把两路角度同步到硬件
 *        作用: 防止任何路径(包括其他模块误改)导致舵机失力/跳变
 */
static void servo_keep_alive_task(void *arg)
{
    (void)arg;
    uint32_t last_diag_tick = 0;

    while (1) {
        esp_err_t ret = servo_apply_both();

        /* 每 10 秒输出一次诊断信息 */
        uint32_t now_tick = xTaskGetTickCount();
        if (now_tick - last_diag_tick >= (10000 / portTICK_PERIOD_MS)) {
            last_diag_tick = now_tick;
            uint32_t duty1, duty2, pulse1, pulse2;
            servo_get_diagnostics(&duty1, &duty2, &pulse1, &pulse2);
            if (ret == ESP_OK) {
                ESP_LOGI(TAG, "舵机状态: 计数=%u, 错误=%u, "
                         "S1=%u°(偏%+d)→物理%u°, S2=%u°(偏%+d)→物理%u°",
                         (unsigned)s_update_count, (unsigned)s_update_errors,
                         s_angle[SERVO_1], (int)s_trim[SERVO_1], 180 - (s_angle[SERVO_1] + s_trim[SERVO_1]),
                         s_angle[SERVO_2], (int)s_trim[SERVO_2], s_angle[SERVO_2] + s_trim[SERVO_2]);
            } else {
                ESP_LOGW(TAG, "舵机更新失败: 计数=%u, 错误=%u",
                         (unsigned)s_update_count, (unsigned)s_update_errors);
            }
        }

        vTaskDelay(pdMS_TO_TICKS(SERVO_KEEP_ALIVE_MS));
    }
}

/**
 * @brief 启动后台"保持运行"任务
 */
esp_err_t servo_keep_alive_start(void)
{
    static bool started = false;
    if (started) return ESP_OK;
    started = true;

    BaseType_t ret = xTaskCreatePinnedToCore(servo_keep_alive_task, "servo_keep",
                                  4096, NULL, 5, NULL, 1);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "后台舵机保持任务创建失败");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "后台舵机保持任务已启动 (周期 %dms)", SERVO_KEEP_ALIVE_MS);
    return ESP_OK;
}

void servo_set_balance_mode(bool enabled)
{
    s_balance_mode = enabled;
}

float servo_get_roll_angle(void)
{
    return s_roll_angle;
}

void servo_set_roll_angle(float roll_deg)
{
    s_roll_angle = roll_deg;
}