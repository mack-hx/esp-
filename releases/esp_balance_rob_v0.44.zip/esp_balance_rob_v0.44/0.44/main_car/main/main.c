/**
 * @file main.c
 * @brief ESP32-S3R8R8N8 平衡轮腿机械狗主程序
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/gpio.h"

#include "hc595.h"
#include "tft_display.h"
#include "led.h"
#include "servo.h"
#include "magnet.h"
#include "motor_driver.h"
#include "encoder.h"
#include "mpu9250.h"
#include "pcf8574.h"
#include "lcd_ui.h"
#include "wifi_sta.h"
#include "param.h"
#include "balance.h"
#include "status_led.h"
#include "rolltest.h"
#include "onenet_client.h"
#include "ble_ctrl.h"
#include "ui_home.h"
#include "ui_menu.h"
#include "ui_balance.h"
#include "ui_servo.h"
#include "ui_encoder.h"
#include "ui_mpu9250.h"
#include "ui_netstat.h"
#include "ui_led_magnet.h"

static const char *TAG = "MAIN";

/* ========== 按键获取回调 (PCF8574 扫描 → UI 按键) ========== */
/**
 * @brief 把 PCF8574 按键位图转换为 UI 按键
 *
 * 优先级: K1 > K3 > K2 > K4
 *   - K1: 进入/确认/退出当前页
 *   - K2: 上/左/减
 *   - K3: 下/右/加
 *   - K4: 减 (备用, 例如 SERVO 调试页 K4 = -5°)
 *
 * 多键同时按下: 只返回优先级最高的那个键
 *
 * 按下电平约定: P0~P7 上拉到 VCC, 按键按下拉低, 即"按下"对应位 = 0。
 *   例: 按下 K1 (P0) → 读 0xFE, 全松开 0xFF
 *
 * @note  本函数只做位图 → UI 键值映射, 不做消抖
 *        (消抖由 pcf8574_scan_buttons() 状态机 + lcd_ui_loop() 边沿检测完成)
 */
static ui_key_t key_get_from_pcf8574(void)
{
    uint8_t state;
    if (pcf8574_scan_buttons(&state) != ESP_OK) {
        return UI_KEY_NONE;
    }
    if (!(state & (1 << BTN_K1))) return UI_KEY_K1;
    if (!(state & (1 << BTN_K3))) return UI_KEY_K3;
    if (!(state & (1 << BTN_K2))) return UI_KEY_K2;
    if (!(state & (1 << BTN_K4))) return UI_KEY_K4;
    return UI_KEY_NONE;
}

/**
 * @brief dummy 按键回调: 始终返回 NONE
 *        当 PCF8574 不可用时使用, 保证 UI 仍然显示
 */
static ui_key_t key_get_none(void)
{
    return UI_KEY_NONE;
}

/**
 * @brief 主函数
 */
void app_main(void)
{
    ESP_LOGI(TAG, "ESP32-S3R8N8 平衡轮腿机械狗启动...");

    /* 初始化 NVS (Non-Volatile Storage) */
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    ESP_LOGI(TAG, "系统初始化完成");
    ESP_LOGI(TAG, "PSRAM: 8MB, Flash: 8MB");

    /* 0. 载入调参参数 (网页滑块调的就是这张表, 必须在用参数之前)
     * 注意: 依赖 NVS, 必须在 nvs_flash_init 之后 */
    param_load();

    /* 1. 初始化 74HC595 (电机方向/电磁铁控制) */
    ESP_ERROR_CHECK(hc595_init());

    /* 0.11 初始化电磁铁 (走 74HC595 Q5/Q6, 默认释放) */
    ESP_ERROR_CHECK(magnet_init());

    /* 2. 初始化 TFT 显示屏 (RST 已接 VCC, 依赖内部 POR) */
    ESP_ERROR_CHECK(tft_display_init());

    /* 3. 初始化 SK6812 LED (RMT 直驱, 支持真实调色调光) */
    ESP_ERROR_CHECK(led_init());
    /* 3.1 开机自检: 红→绿→蓝, 用来肉眼确认 LED 到底通没通 */
    led_selftest();

    /* 4. 初始化舵机 (归位到 SERVO_DEFAULT_ANGLE, 默认舵机2 镜像) */
    ESP_ERROR_CHECK(servo_init());

    /* 4.1 启动后台"保持运行"任务: 持续 sync 舵机硬件, 跨页不失力/不跳变 */
    ESP_ERROR_CHECK(servo_keep_alive_start());

    /* 5. 初始化电机 (制动状态) */
    ESP_ERROR_CHECK(motor_driver_init());
    ESP_ERROR_CHECK(motor_brake_all());

    /* 6. 初始化编码器 */
    ESP_ERROR_CHECK(encoder_init());

    /* 6.1 初始化 PCF8574 (按键 + 对接微动开关) - 允许失败: 模块可能未接
     * 提前到这里是因为 OneNet 上报任务要读 P4/P5 两个微动开关 (对接检测) */
    esp_err_t pcf_ret = pcf8574_init();
    if (pcf_ret != ESP_OK) {
        ESP_LOGE(TAG, "PCF8574 初始化失败 (按键模块未接), UI 无法响应按键");
        ESP_LOGE(TAG, "请检查 PCF8574 模块接线 (SCL=GPIO%d, SDA=GPIO%d, INT=GPIO%d, VCC, GND)",
                 PCF8574_SCL_GPIO, PCF8574_SDA_GPIO, PCF8574_INT_GPIO);
    }

    /* 7. 初始化 MPU9250 (允许失败: 模块可能未接, UI 显示 "NOT READY")
     * 重试 10 次: 上电瞬间 IMU 供电/内部时钟可能未稳, 单次读 WHO_AM_I
     * 失败会导致整次上电都处于 MPU 不可用状态。 */
    esp_err_t mpu_ret = ESP_FAIL;
    for (int i = 0; i < 10 && mpu_ret != ESP_OK; i++) {
        mpu_ret = mpu9250_init();
        if (mpu_ret != ESP_OK) {
            ESP_LOGW(TAG, "MPU9250 初始化失败 (第 %d 次), 500ms 后重试", i + 1);
            vTaskDelay(pdMS_TO_TICKS(500));
        }
    }
    if (mpu_ret != ESP_OK) {
        ESP_LOGE(TAG, "MPU9250 初始化失败 (模块未接或 I2C 故障), UI 仍可正常工作");
        ESP_LOGE(TAG, "请检查 MPU9250 模块接线 (SCL=GPIO%d, SDA=GPIO%d, VCC, GND, AD0)",
                 MPU9250_SCL_GPIO, MPU9250_SDA_GPIO);
    }

    /* 8. 初始化平衡控制 (读 param + 载入配平表 + 启动控制任务)
     * 必须在 MPU9250 / 编码器 / 电机 / 舵机 之后; 允许失败 */
    esp_err_t bal_ret = balance_init();
    if (bal_ret != ESP_OK) {
        ESP_LOGE(TAG, "平衡控制初始化失败 (%s)", esp_err_to_name(bal_ret));
    }

    /* 8.0.1 启动状态灯: 依赖 balance/servo/magnet/pcf8574, 必须在它们之后 */
    if (status_led_start() != ESP_OK) {
        ESP_LOGW(TAG, "状态灯任务未启动, 灯只受 App/LCD 手动控制");
    }

    /* 8.0.2 横滚角实测工具 (串口命令, 允许失败) */
    rolltest_start();

    /* 8.0 启动 BLE 直控: 控制器要连续的内部 RAM, 必须在 WiFi/MQTT 占用内存之前; 允许失败 */
    esp_err_t ble_ret = ble_ctrl_start();
    if (ble_ret != ESP_OK) {
        ESP_LOGE(TAG, "BLE 启动失败 (%s), 蓝牙直控不可用", esp_err_to_name(ble_ret));
    }

    /* 8.1 启动 WiFi (STA 模式连家里 WiFi, 没配过进 AP 配网)
     * WiFi 驱动依赖 NVS, 必须在 nvs_flash_init 之后调用; 允许失败 */
    esp_err_t wifi_ret = wifi_sta_start();
    if (wifi_ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi 启动失败, OneNet 远程不可用 (%s)",
                 esp_err_to_name(wifi_ret));
    }

    /* 8.2 启动 OneNet MQTT 客户端 (走物模型 topic)
     * 必须在 wifi_sta_start() 之后 (要走外网); 允许失败 */
    esp_err_t mqtt_ret = mqtt_client_start();
    if (mqtt_ret != ESP_OK) {
        ESP_LOGE(TAG, "OneNet MQTT 启动失败 (%s), App 远程不可用", esp_err_to_name(mqtt_ret));
    }

    /* ========================================================
     * UI 系统初始化
     * ======================================================== */
    /* 注册所有页面 (顺序不影响, 但 HOME 必须先注册) */
    ESP_ERROR_CHECK(ui_home_register());
    ESP_ERROR_CHECK(ui_menu_register());
    ESP_ERROR_CHECK(ui_balance_register());
    ESP_ERROR_CHECK(ui_servo_register());
    ESP_ERROR_CHECK(ui_encoder_register());
    ESP_ERROR_CHECK(ui_mpu9250_register());
    ESP_ERROR_CHECK(ui_netstat_register());
    ESP_ERROR_CHECK(ui_led_magnet_register());

    /* 根据 PCF8574 是否就绪, 选择按键回调
     * - 就绪: 从 PCF8574 读取真实按键
     * - 未就绪: 用 dummy 回调 (返回 NONE, UI 仍然显示但按键无效) */
    ui_key_get_t key_cb = (pcf_ret == ESP_OK) ? key_get_from_pcf8574 : key_get_none;

    /* 初始化 UI 系统 (会在主页显示初始画面) */
    ESP_ERROR_CHECK(lcd_ui_init(key_cb));

    ESP_LOGI(TAG, "UI 系统就绪, 进入主循环");

    /* 主循环 (按键扫描 + UI 调度 + 页面刷新) */
    while (1) {
        lcd_ui_loop();
        vTaskDelay(pdMS_TO_TICKS(50));  // 50ms 周期
    }
}