/**
 * @file trace.h
 * @brief 控制回路跟踪: 环形缓冲采集 + 独立任务回灌串口
 *
 * @note  采集 (trace_push) 只写内存环形缓冲, 控制任务调用, 不碰串口;
 *        打印与历史回灌在钉在 core 0 的独立任务里做 (控制任务钉在 core 1)。
 *
 * @note  数据格式 (固件 / 采集脚本 / 分析脚本 三方统一):
 *   TRACE t=1.234 pitch=-0.50 gyro=-12.3 out=8.0 tgt=0.20 spd=2.0
 *         yaw=0.0 pos=1.2 pos_err=0.3 pos_out=0.0 kd=0.40 dt=10.0 st=2
 *   对应 CSV 表头:
 *     t_ms,pitch,gyro,out,tgt,spd,yaw,pos,pos_err,pos_out,pos_vel,kd,dt,st
 *
 * @author ESP32 平衡轮腿机器人
 */

#ifndef TRACE_H
#define TRACE_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ========== 一条控制回路采样 ========== */
typedef struct {
    float t;          /* esp_timer 时刻 (秒) */
    float pitch;      /* 修正后姿态角 (°) */
    float gyro;       /* 俯仰角速度 (°/s) */
    float out;        /* 平衡环输出 (%) */
    float tgt;        /* 目标倾角 (°) */
    float spd;        /* 实测轮速 (rpm) */
    float yaw;        /* 差速输出 (%) */
    float pos;        /* 位置 (cm) */
    float pos_err;    /* 位置误差 (cm): 锚点位置 - 当前位置 */
    float pos_out;    /* 位置保持环输出的倾角 (°, 前倾为正), 未乘权重 */
    float pos_vel;    /* 里程计速度 (cm/s): 位置保持环的阻尼输入, 看它对不对 */
    float kd;         /* 采样时刻的平衡环 Kd (参数可热改, 必须逐条记) */
    float dt;         /* 本周期实测间隔 (ms) */
    int8_t st;        /* 状态机状态 (bal_state_t) */
} trace_sample_t;

/**
 * @brief 初始化跟踪模块 (创建输出任务)
 * @note  必须在控制任务启动**之前**调用
 */
void trace_init(void);

/**
 * @brief 采一条样存进环形缓冲 (控制任务调用, 不做串口 I/O)
 * @param s 采样数据 (内部按值拷贝)
 * @note  耗时几百纳秒, 每个控制周期调一次即可 (10ms → 100Hz)
 */
void trace_push(const trace_sample_t *s);

/**
 * @brief 请求把环形缓冲里的历史回灌到串口 (控制任务调用, 不阻塞)
 * @note  真正的打印在独立任务里做, 调用方立即返回
 */
void trace_request_dump(void);

#ifdef __cplusplus
}
#endif

#endif /* TRACE_H */
