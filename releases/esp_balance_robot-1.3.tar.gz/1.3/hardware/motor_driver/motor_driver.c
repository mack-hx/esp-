/**
 * @file motor_driver.c
 * @brief TB6612FNG 双路直流电机驱动实现
 * @note  方向控制引脚由 74HC595 提供, 此处通过调用 hc595 API 控制
 * @author ESP32 机械狗项目
 * @date 2026-10-01
 */

#include "motor_driver.h"
#include "driver/ledc.h"
#include "esp_log.h"
#include "hc595.h"

static const char *TAG = "MOTOR";

/* 电机 GPIO 与 LEDC 通道映射 */
static const struct {
    gpio_num_t      gpio;
    ledc_channel_t  channel;
} motor_map[MOTOR_B + 1] = {
    [MOTOR_A] = { .gpio = MOTOR_PWMA_GPIO, .channel = MOTOR_A_CHANNEL },
    [MOTOR_B] = { .gpio = MOTOR_PWMB_GPIO, .channel = MOTOR_B_CHANNEL },
};

/* 当前方向缓存 */
static motor_dir_t current_dir[MOTOR_B + 1] = {
    [MOTOR_A] = MOTOR_DIR_BRAKE,
    [MOTOR_B] = MOTOR_DIR_BRAKE,
};

/**
 * @brief 将速度 (-100~100) 转换为 LEDC 占空比
 */
static uint32_t motor_speed_to_duty(int8_t speed)
{
    if (speed < 0) speed = -speed;
    if (speed > MOTOR_SPEED_MAX) speed = MOTOR_SPEED_MAX;
    uint32_t max_duty = (1 << 10) - 1;  // 10 bit 分辨率
    return (uint32_t)(((uint32_t)speed * max_duty) / MOTOR_SPEED_MAX);
}

/**
 * @brief 应用死区补偿后的占空比
 * @param duty      原始占空比 (0~1023)
 * @param deadzone  最小启动占空比 (0=不补偿)
 * @return 补偿后的占空比
 *
 * @brief 为什么要这个 (2026-10-05, 参照 WL1)
 *   直流电机 + TB6612 都有**起动死区**: 摩擦力和反电动势决定, 占空比低于
 *   某个值时电机根本不转, 输出 0。但对平衡车来说, PID 在接近平衡点时
 *   输出会长时间停在这个"转不动"的小值区间里, 表现为:
 *     - 车慢慢往一边倒, 电机明明有输出却不动
 *     - 或者突然越过死区猛冲一下
 *   也就是俗称的"低速爬行 + 突跳"。
 *
 *   补偿办法: 输出非零但小于死区时, 抬到死区值。
 *   ⚠ 只对**非零**输出生效, 0 保持 0 —— 0 必须是真的停, 不能被抬成
 *     "最低转速", 否则车停不住。这是 WL1 里那段代码的关键分支。
 *
 * @note  补偿是"抬到"而不是"加上", 所以死区以上区域完全不变,
 *        不会让大输出变得更大。
 */
static uint32_t motor_apply_deadzone(uint32_t duty, int8_t deadzone)
{
    if (duty == 0) return 0;                 /* 真停: 不补偿 */
    if (deadzone <= 0) return duty;

    uint32_t dz = (uint32_t)(((uint32_t)deadzone * ((1 << 10) - 1)) / MOTOR_SPEED_MAX);
    return (duty < dz) ? dz : duty;
}

/* 当前死区设置 (%) 由 balance.c 写入; 默认 0 = 不补偿, 保持旧行为不变 */
static int8_t s_motor_deadzone = 0;

/**
 * @brief 应用方向到 74HC595
 * @note  实际硬件映射 (2026-10-03 逐位测试确认):
 *   电机 A (PWMA=GPIO15):
 *     AIN1 = HC595_Q5  (0x20 = 正转, 0x40=反转, 0x00=制动)
 *     AIN2 = HC595_Q6
 *   电机 B (PWMB=GPIO16):
 *     BIN1 = HC595_Q3  (0x08 = 正转, 0x10=反转, 0x00=制动)
 *     BIN2 = HC595_Q4
 * TB6612 真值表: (IN1=0, IN2=1)=正转  (IN1=1, IN2=0)=反转
 */
static esp_err_t motor_apply_direction(motor_id_t motor, motor_dir_t dir)
{
    hc595_pin_t in1_pin = (motor == MOTOR_A) ? HC595_Q5 : HC595_Q3;
    hc595_pin_t in2_pin = (motor == MOTOR_A) ? HC595_Q6 : HC595_Q4;
    bool in1 = false, in2 = false;

    switch (dir) {
        case MOTOR_DIR_BRAKE:
            in1 = false; in2 = false;
            break;
        case MOTOR_DIR_FORWARD:
            in1 = false; in2 = true;
            break;
        case MOTOR_DIR_REVERSE:
            in1 = true; in2 = false;
            break;
        default:
            ESP_LOGE(TAG, "无效的电机方向: %d", dir);
            return ESP_ERR_INVALID_ARG;
    }

    esp_err_t ret = hc595_set_pin(in1_pin, in1);
    if (ret != ESP_OK) return ret;
    ret = hc595_set_pin(in2_pin, in2);
    if (ret == ESP_OK) {
        current_dir[motor] = dir;
    }
    return ret;
}

/**
 * @brief 初始化电机驱动
 */
esp_err_t motor_driver_init(void)
{
    /* 配置 LEDC 定时器 */
    ledc_timer_config_t timer_cfg = {
        .duty_resolution = MOTOR_PWM_RES,
        .freq_hz = MOTOR_PWM_FREQ,
        .speed_mode = MOTOR_PWM_MODE,
        .timer_num = MOTOR_PWM_TIMER,
        .clk_cfg = LEDC_AUTO_CLK,
    };

    esp_err_t ret = ledc_timer_config(&timer_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "LEDC 定时器配置失败");
        return ret;
    }

    /* 配置两个电机的 LEDC 通道 */
    for (int i = 0; i <= MOTOR_B; i++) {
        ledc_channel_config_t ch_cfg = {
            .channel    = motor_map[i].channel,
            .duty       = 0,
            .gpio_num   = motor_map[i].gpio,
            .speed_mode = MOTOR_PWM_MODE,
            .timer_sel  = MOTOR_PWM_TIMER,
        };

        ret = ledc_channel_config(&ch_cfg);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "电机 %c 通道配置失败", 'A' + i);
            return ret;
        }
    }

    /* 初始状态: 制动 + 零速 */
    for (int i = 0; i <= MOTOR_B; i++) {
        motor_apply_direction((motor_id_t)i, MOTOR_DIR_BRAKE);
        motor_set_speed((motor_id_t)i, 0);
    }

    ESP_LOGI(TAG, "电机驱动初始化成功 (PWMA=%d, PWMB=%d, %dkHz)",
             MOTOR_PWMA_GPIO, MOTOR_PWMB_GPIO, MOTOR_PWM_FREQ / 1000);
    return ESP_OK;
}

/**
 * @brief 设置单个电机方向
 */
esp_err_t motor_set_direction(motor_id_t motor, motor_dir_t dir)
{
    if (motor > MOTOR_B) {
        return ESP_ERR_INVALID_ARG;
    }
    return motor_apply_direction(motor, dir);
}

/**
 * @brief 设置单个电机速度
 */
esp_err_t motor_set_speed(motor_id_t motor, int8_t speed)
{
    if (motor > MOTOR_B) {
        return ESP_ERR_INVALID_ARG;
    }

    /* 根据速度符号自动调整方向 */
    motor_dir_t target_dir;
    if (speed > 0) {
        target_dir = MOTOR_DIR_FORWARD;
    } else if (speed < 0) {
        target_dir = MOTOR_DIR_REVERSE;
    } else {
        target_dir = MOTOR_DIR_BRAKE;
    }

    if (target_dir != current_dir[motor]) {
        esp_err_t ret = motor_apply_direction(motor, target_dir);
        if (ret != ESP_OK) return ret;
    }

    uint32_t duty = motor_speed_to_duty(speed);
    duty = motor_apply_deadzone(duty, s_motor_deadzone);
    esp_err_t ret = ledc_set_duty(MOTOR_PWM_MODE, motor_map[motor].channel, duty);
    if (ret != ESP_OK) return ret;
    return ledc_update_duty(MOTOR_PWM_MODE, motor_map[motor].channel);
}

/**
 * @brief 设置电机起动死区补偿值
 * @param deadzone 最小启动占空比 (0~30, 单位 %; 0=不补偿)
 * @return ESP_OK 成功; ESP_ERR_INVALID_ARG 超出合法范围
 *
 * @note  只影响**非零**输出, 见 motor_apply_deadzone() 的说明。
 * @note  超出 MOTOR_DEADBAND_MAX 时自动夹到上限, 不报错 (滑块可能超范围)。
 */
esp_err_t motor_set_deadband(int8_t deadzone)
{
    if (deadzone < 0) deadzone = 0;
    if (deadzone > MOTOR_DEADBAND_MAX) deadzone = MOTOR_DEADBAND_MAX;
    s_motor_deadzone = deadzone;
    return ESP_OK;
}

/**
 * @brief 读取当前死区设置 (%)
 */
int8_t motor_get_deadband(void)
{
    return s_motor_deadzone;
}

/**
 * @brief 同时控制两个电机
 */
esp_err_t motor_set_speed_both(int8_t speed_a, int8_t speed_b)
{
    esp_err_t ret = motor_set_speed(MOTOR_A, speed_a);
    if (ret != ESP_OK) return ret;
    return motor_set_speed(MOTOR_B, speed_b);
}

/**
 * @brief 制动单个电机
 */
esp_err_t motor_brake(motor_id_t motor)
{
    if (motor > MOTOR_B) {
        return ESP_ERR_INVALID_ARG;
    }

    /* ⚠ 制动走 ledc_set_duty(0) 直写, **不经过** motor_apply_deadzone(),
     *   所以死区补偿不会把制动抬成"最低转速"。这正是我们要的行为:
     *   停车必须真的停。死区只作用在 motor_set_speed() 的非零输出上。 */
    esp_err_t ret = ledc_set_duty(MOTOR_PWM_MODE, motor_map[motor].channel, 0);
    if (ret != ESP_OK) return ret;
    ret = ledc_update_duty(MOTOR_PWM_MODE, motor_map[motor].channel);
    if (ret != ESP_OK) return ret;

    return motor_apply_direction(motor, MOTOR_DIR_BRAKE);
}

/**
 * @brief 制动两个电机
 */
esp_err_t motor_brake_all(void)
{
    esp_err_t ret = motor_brake(MOTOR_A);
    if (ret != ESP_OK) return ret;
    return motor_brake(MOTOR_B);
}